package com.example.Event.Ticketing.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventTicketingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
